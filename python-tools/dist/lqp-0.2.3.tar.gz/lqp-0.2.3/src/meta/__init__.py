"""Meta-language tools for translating protobuf specification into parsers and pretty printers.

This package provides tools for:
- Parsing protobuf specifications
- Generating context-free grammars with semantic actions
- Generating parsers from the grammar
- Generating pretty printers from the grammar
"""

# Target language AST
from .target import (
    TargetNode,
    TargetExpr,
    Var,
    Lit,
    Symbol,
    Builtin,
    Call,
    Lambda,
    Let,
    IfElse,
    Seq,
    While,
    Assign,
    TargetType,
    BaseType,
    TupleType,
    ListType,
    FunDef,
    VisitNonterminalDef,
    VisitNonterminal,
)

# Grammar data structures
from .grammar import (
    Grammar,
    Rule,
    Token,
    Rhs,
    Terminal,
    LitTerminal,
    NamedTerminal,
    Nonterminal,
    Star,
    Option,
)

# Protobuf AST
from .proto_ast import (
    ProtoField,
    ProtoOneof,
    ProtoEnum,
    ProtoMessage,
)

# Protobuf parser
from .proto_parser import ProtoParser

# Parser generation
from .parser_gen import generate_parse_functions, GrammarConflictError, AmbiguousGrammarError

# Python code generation
from .codegen_python import (
    generate_python,
    generate_python_lines,
    escape_identifier as escape_python_identifier,
)

# Julia code generation
from .codegen_julia import (
    generate_julia,
    generate_julia_lines,
    generate_julia_def,
    escape_identifier as escape_julia_identifier,
)

from .parser_gen_python import generate_parser_python
from .parser_gen_julia import generate_parser_julia

__all__ = [
    # Target language AST
    'TargetNode',
    'TargetExpr',
    'Var',
    'Lit',
    'Symbol',
    'Builtin',
    'Call',
    'Lambda',
    'Let',
    'IfElse',
    'Seq',
    'While',
    'Assign',
    'TargetType',
    'BaseType',
    'TupleType',
    'ListType',
    'FunDef',
    'VisitNonterminalDef',
    'VisitNonterminal',
    # Grammar
    'Grammar',
    'Rule',
    'Token',
    'Rhs',
    'Terminal',
    'LitTerminal',
    'NamedTerminal',
    'Nonterminal',
    'Star',
    'Option',
    # Protobuf AST
    'ProtoField',
    'ProtoOneof',
    'ProtoEnum',
    'ProtoMessage',
    # Protobuf parser
    'ProtoParser',
    # Parser generation
    'generate_parse_functions',
    'GrammarConflictError',
    'AmbiguousGrammarError',
    'generate_parser_python',
    'generate_parser_julia',
    # Python code generation
    'generate_python',
    'generate_python_lines',
    'escape_python_identifier',
    # Julia code generation
    'generate_julia',
    'generate_julia_lines',
    'generate_julia_def',
    'escape_julia_identifier',
]
